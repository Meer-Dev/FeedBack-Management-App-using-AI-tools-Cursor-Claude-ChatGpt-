﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace CourseFeedbackSystem.Migrations;

/// <inheritdoc />
public partial class Upgraded_To_Abp_9_1 : Migration
{
    /// <inheritdoc />
    protected override void Up(MigrationBuilder migrationBuilder)
    {
        migrationBuilder.AlterColumn<string>(
            name: "Discriminator",
            table: "AbpPermissions",
            type: "nvarchar(21)",
            maxLength: 21,
            nullable: false,
            oldClrType: typeof(string),
            oldType: "nvarchar(max)");

        migrationBuilder.AddColumn<string>(
            name: "TargetNotifiers",
            table: "AbpNotificationSubscriptions",
            type: "nvarchar(1024)",
            maxLength: 1024,
            nullable: true);

        migrationBuilder.AlterColumn<string>(
            name: "Discriminator",
            table: "AbpFeatures",
            type: "nvarchar(21)",
            maxLength: 21,
            nullable: false,
            oldClrType: typeof(string),
            oldType: "nvarchar(max)");
    }

    /// <inheritdoc />
    protected override void Down(MigrationBuilder migrationBuilder)
    {
        migrationBuilder.DropColumn(
            name: "TargetNotifiers",
            table: "AbpNotificationSubscriptions");

        migrationBuilder.AlterColumn<string>(
            name: "Discriminator",
            table: "AbpPermissions",
            type: "nvarchar(max)",
            nullable: false,
            oldClrType: typeof(string),
            oldType: "nvarchar(21)",
            oldMaxLength: 21);

        migrationBuilder.AlterColumn<string>(
            name: "Discriminator",
            table: "AbpFeatures",
            type: "nvarchar(max)",
            nullable: false,
            oldClrType: typeof(string),
            oldType: "nvarchar(21)",
            oldMaxLength: 21);
    }
}
